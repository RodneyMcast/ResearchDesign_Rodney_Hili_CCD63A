using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class LevelObjectiveTracker : MonoBehaviour
{
    [Serializable]
    public class Step
    {
        public string actionId;
        [TextArea] public string hintText;
    }

    [Header("Level Steps (in order)")]
    public List<Step> steps = new();

    [Header("Win Conditions")]
    [Tooltip("If this specific action is recorded, the user wins immediately regardless of their current step.")]
    public string winActionId = "MasterWin";
    public UnityEvent onWin;

    [Header("Debug")]
    public bool logProgress = true;

    [Header("Optional")]
    public bool resetProgressOnEnable = true;

    public int CurrentStepIndex => _currentStepIndex;
    public int TotalSteps => steps == null ? 0 : steps.Count;
    
    public float NormalizedProgress => TotalSteps <= 0 ? 0f : Mathf.Clamp01((float)_currentStepIndex / TotalSteps);
    public float GetProgress01() => NormalizedProgress;

    public event Action<int, int> OnProgressChanged;

    private int _currentStepIndex = 0;
    private bool _subscribed = false;
    private Coroutine _waitRoutine;

    private void OnEnable()
    {
        if (resetProgressOnEnable) 
            _currentStepIndex = 0;

        if (_waitRoutine != null) StopCoroutine(_waitRoutine);
        _waitRoutine = StartCoroutine(WaitForGameManagerThenSubscribe());
    }

    private void OnDisable()
    {
        Unsubscribe();
        if (_waitRoutine != null)
        {
            StopCoroutine(_waitRoutine);
            _waitRoutine = null;
        }
    }

    private IEnumerator WaitForGameManagerThenSubscribe()
    {
        while (GameManager.Instance == null)
        {
            if (logProgress)
                Debug.LogWarning("[LevelObjectiveTracker] Waiting for GameManager.Instance...");
            yield return null;
        }

        Subscribe();

        
        yield return new WaitForEndOfFrame();
        NotifyProgress();
    }

    private void Subscribe()
    {
        if (_subscribed) return;

        GameManager.Instance.OnActionRecorded -= HandleAction;
        GameManager.Instance.OnActionRecorded += HandleAction;

        _subscribed = true;

        if (logProgress)
            Debug.Log("[LevelObjectiveTracker] Subscribed to GameManager actions ✅");
    }

    private void Unsubscribe()
    {
        if (!_subscribed) return;

        if (GameManager.Instance != null)
            GameManager.Instance.OnActionRecorded -= HandleAction;

        _subscribed = false;
    }

    private void HandleAction(string actionId)
    {
        if (_currentStepIndex >= TotalSteps) return;

        string received = (actionId ?? "").Trim();

        
        if (!string.IsNullOrEmpty(winActionId) && 
            string.Equals(received, winActionId.Trim(), StringComparison.OrdinalIgnoreCase))
        {
            if (logProgress)
                Debug.Log($"[LevelObjectiveTracker] MASTER WIN TRIGGERED: '{received}'");
            
            _currentStepIndex = TotalSteps; 
            NotifyProgress();
            onWin?.Invoke();
            return;
        }

       
        bool stepFound = false;
        for (int i = _currentStepIndex; i < TotalSteps; i++)
        {
            string expected = (steps[i].actionId ?? "").Trim();

            if (string.Equals(received, expected, StringComparison.OrdinalIgnoreCase))
            {
                _currentStepIndex = i + 1; 
                stepFound = true;
                break; 
            }
        }

        if (stepFound)
        {
            if (logProgress)
                Debug.Log($"[LevelObjectiveTracker] Progress updated to step {_currentStepIndex}/{TotalSteps}");

            NotifyProgress();

            if (_currentStepIndex >= TotalSteps)
            {
                if (logProgress) Debug.Log("[LevelObjectiveTracker] LEVEL COMPLETE 🏁");
                onWin?.Invoke();
            }
        }
    }

    private void NotifyProgress()
    {
        OnProgressChanged?.Invoke(_currentStepIndex, TotalSteps);
    }

    public string GetCurrentHint()
    {
        if (_currentStepIndex >= TotalSteps) return "Done!";
        return steps[_currentStepIndex].hintText;
    }
}