using UnityEngine;
using TMPro; 

public class HintButton : MonoBehaviour
{
    [SerializeField] private LevelObjectiveTracker tracker;
    [SerializeField] private string actionId = "hint_requested";
    
    
    [SerializeField] private TextMeshProUGUI hintDisplay; 

    public void ShowHint()
    {
        if (tracker == null)
        {
            Debug.LogWarning("[HintButton] No LevelObjectiveTracker assigned.");
            return;
        }

        var hint = tracker.GetCurrentHint();
        Debug.Log($"[HINT] {hint}");

        
        if (hintDisplay != null)
        {
            hintDisplay.text = hint;
        }

        if (GameManager.Instance != null && !string.IsNullOrEmpty(actionId))
            GameManager.Instance.RecordAction(actionId);
    }
}