using UnityEngine;
using UnityEngine.InputSystem; // Required for the New Input System

public class GamificationManager : MonoBehaviour
{
    [Header("UI References")]
    [Tooltip("Assign the GameObject that contains your Progress Bar.")]
    public GameObject progressBarUI;

    [Header("Settings")]
    public bool hideOnStart = true;

    private bool _isVisible;

    private void Start()
    {
        if (progressBarUI != null)
        {
            _isVisible = !hideOnStart;
            progressBarUI.SetActive(_isVisible);
        }
    }

    private void Update()
    {
        // New Input System check for Caps Lock
        if (Keyboard.current != null && Keyboard.current.capsLockKey.wasPressedThisFrame)
        {
            ToggleProgressBar();
        }
    }

    private void ToggleProgressBar()
    {
        if (progressBarUI == null) return;

        _isVisible = !_isVisible;
        progressBarUI.SetActive(_isVisible);
        
        Debug.Log($"[GamificationManager] Progress Bar visible: {_isVisible}");
    }
}