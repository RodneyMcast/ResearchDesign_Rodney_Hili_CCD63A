using System;
using System.Linq;

public static class AssistantPromptRouter
{
    public static bool TryResolve(
        AssistantPromptRegistry registry,
        string userPrompt,
        out AssistantPromptRegistry.Entry bestEntry)
    {
        bestEntry = null;
        if (registry == null || registry.entries == null) return false;

        var prompt = Normalize(userPrompt);
        if (string.IsNullOrEmpty(prompt)) return false;

        int bestScore = int.MinValue;

        foreach (var entry in registry.entries)
        {
            if (entry == null || entry.keywords == null || entry.keywords.Count == 0) continue;

            int entryBest = int.MinValue;

            foreach (var rawK in entry.keywords)
            {
                var k = Normalize(rawK);
                if (string.IsNullOrEmpty(k)) continue;

                // Match strength points (bigger = better)
                // exact > contains > typo
                int strength = int.MinValue;

                if (prompt == k)
                {
                    strength = 3000;
                }
                else if (entry.allowContainsMatch && prompt.Contains(k))
                {
                    strength = 2000 + Math.Min(200, k.Length); // slightly prefer longer contains
                }
                else if (entry.maxEditDistance > 0)
                {
                    // Compare keyword to prompt AND to each token (helps with "iphone near me")
                    int distPrompt = Levenshtein(prompt, k);
                    int distToken = prompt.Split(' ')
                        .Select(t => Levenshtein(t, k))
                        .DefaultIfEmpty(999)
                        .Min();

                    int dist = Math.Min(distPrompt, distToken);

                    if (dist <= entry.maxEditDistance)
                    {
                        strength = 1000 - (dist * 50); // closer typo = better
                    }
                }

                if (strength > entryBest)
                    entryBest = strength;
            }

            if (entryBest == int.MinValue) continue;

            // Final score uses priority as tie-breaker / preference
            int score = entryBest + (entry.priority * 10);

            if (score > bestScore)
            {
                bestScore = score;
                bestEntry = entry;
            }
        }

        return bestEntry != null;
    }

    private static string Normalize(string s)
    {
        if (string.IsNullOrWhiteSpace(s)) return "";
        return string.Join(" ", s.Trim().ToLower().Split(new[] { ' ', '\t', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries));
    }

    private static int Levenshtein(string a, string b)
    {
        if (a == b) return 0;
        if (a.Length == 0) return b.Length;
        if (b.Length == 0) return a.Length;

        int[,] d = new int[a.Length + 1, b.Length + 1];

        for (int i = 0; i <= a.Length; i++) d[i, 0] = i;
        for (int j = 0; j <= b.Length; j++) d[0, j] = j;

        for (int i = 1; i <= a.Length; i++)
        {
            for (int j = 1; j <= b.Length; j++)
            {
                int cost = (a[i - 1] == b[j - 1]) ? 0 : 1;
                d[i, j] = Math.Min(
                    Math.Min(d[i - 1, j] + 1, d[i, j - 1] + 1),
                    d[i - 1, j - 1] + cost
                );
            }
        }

        return d[a.Length, b.Length];
    }
}
